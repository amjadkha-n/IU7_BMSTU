#!/bin/bash
dot -Tsvg ./bin_tree.gv > bin_tree.svg
dot -Tsvg ./avl_tree.gv > avl_tree.svg
